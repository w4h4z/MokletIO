CKEDITOR.plugins.addExternal('embed', '/assets/global/plugins/ckeditor/plugins/embed/', 'plugin.js');
CKEDITOR.plugins.addExternal('embedbase', '/assets/global/plugins/ckeditor/plugins/embedbase/', 'plugin.js');
CKEDITOR.plugins.addExternal('notificationaggregator', '/assets/global/plugins/ckeditor/plugins/notificationaggregator/', 'plugin.js');
CKEDITOR.plugins.addExternal('widget', '/assets/global/plugins/ckeditor/plugins/widget/', 'plugin.js');
CKEDITOR.plugins.addExternal('notification', '/assets/global/plugins/ckeditor/plugins/notification/', 'plugin.js');
CKEDITOR.plugins.addExternal('lineutils', '/assets/global/plugins/ckeditor/plugins/lineutils/', 'plugin.js');
CKEDITOR.plugins.addExternal('widgetselection', '/assets/global/plugins/ckeditor/plugins/widgetselection/', 'plugin.js');

CKEDITOR.on( 'instanceCreated', function ( event ) {
    var editor = event.editor,
        element = editor.element;

    if ( element.is( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ) ) {
        editor.on( 'configLoaded', function () {

            editor.config.removePlugins = 'colorbutton,find,flash,font,' +
                'forms,iframe,image,newpage,removeformat,' +
                'smiley,specialchar,stylescombo,templates';

            editor.config.toolbarGroups = [
                { name: 'editing', groups: [ 'basicstyles', 'links' ] },
                { name: 'undo' },
                { name: 'clipboard', groups: [ 'selection', 'clipboard' ] }
            ];
        } );
    }

    if(element.is('div')){
        editor.config.extraPlugins = 'embed';

        editor.on( 'configLoaded', function () {
            editor.config.toolbar = [
                {name: 'clipboard', items: ['Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo']},
                {name: 'editing', items: ['Find', 'Replace', '-', 'SelectAll']},
                {name: 'basicstyles', items: ['Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript']},
                '/',
                {name: 'paragraph', items: ['NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock']},
                {name: 'links', items: ['Link', 'Unlink']},
                {name: 'insert', items: ['Image', 'Embed', 'Table']},
                {name: 'colors', items: ['TextColor', 'BGColor']},
                '/',
                {name: 'styles', items: ['Styles', 'Format', 'Font', 'FontSize']}
            ];
        });
    }

} );